# EVO WALLS Android App

A GitHub-ready Android Studio project for the EVO WALLS wallpaper app.

## What is already implemented
- Black/red EVO WALLS visual theme
- Home
- Explore
- Category filters
- Wallpaper grid
- Wallpaper detail
- Favorites in current session
- Premium UI / demo unlock
- Profile
- Set wallpaper using Android WallpaperManager
- GitHub Actions debug APK build
- Selected EVO WALLS design assets bundled into drawable resources

## Build on GitHub
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Commit to `main` or `master`.
4. Open GitHub → Actions → `Build EVO WALLS APK`.
5. Run the workflow.
6. Download `EVO-WALLS-debug-apk` from the workflow's Artifacts section.

## Build locally
Open this folder in Android Studio and run:
`gradle assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Important
Premium is currently a UI/demo flow. Real Google Play Billing needs to be connected before publishing.
The included wallpaper images are placeholders/design assets. Replace them with original or properly licensed wallpaper content for a commercial release.
