package com.evowalls.app

import android.app.WallpaperManager
import android.content.Context
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Bg = Color(0xFF09090B)
private val Surface = Color(0xFF141417)
private val Red = Color(0xFFF52337)
private val Text = Color(0xFFF5F5F7)
private val Muted = Color(0xFF9B9BA5)

data class Wall(val title:String, val category:String, val res:Int, val premium:Boolean=false)

@Composable
fun EvoTheme(content:@Composable ()->Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background=Bg, surface=Surface, primary=Red,
            onBackground=Text, onSurface=Text, onPrimary=Color.Black
        ),
        content=content
    )
}

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EvoTheme { EvoApp() } }
    }
}

@Composable
fun EvoApp() {
    val ctx=LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var category by remember { mutableStateOf("All") }
    var selected by remember { mutableStateOf<Wall?>(null) }
    var premium by remember { mutableStateOf(false) }
    val favorites=remember { mutableStateListOf<Int>() }

    val walls = remember {
        listOf(
            Wall("JDM Night","Cars",R.drawable.wall_wallpaper_sections_01_cars_cars_01_jpg),
            Wall("JDM Red","Cars",R.drawable.wall_wallpaper_sections_01_cars_cars_02_jpg,true),
            Wall("4K Ring","4K",R.drawable.wall_wallpaper_sections_02_4k_4k_01_jpg),
            Wall("Mountain Light","Nature",R.drawable.wall_wallpaper_sections_03_nature_nature_01_jpg),
            Wall("AMOLED Core","AMOLED",R.drawable.wall_wallpaper_sections_04_amoled_amoled_01_jpg),
            Wall("Gaming Mode","Gaming",R.drawable.wall_wallpaper_sections_05_gaming_gaming_01_jpg),
            Wall("Anime Red","Anime",R.drawable.wall_wallpaper_sections_06_anime_anime_01_jpg),
            Wall("Abstract Ring","Abstract",R.drawable.wall_wallpaper_sections_07_abstract_abstract_01_jpg),
            Wall("Minimal Line","Minimal",R.drawable.wall_wallpaper_sections_08_minimal_minimal_01_jpg),
            Wall("Cosmic","Space",R.drawable.wall_wallpaper_sections_09_space_space_01_jpg),
            Wall("Neon Night","Neon",R.drawable.wall_wallpaper_sections_10_neon_neon_01_jpg),
            Wall("Moto Life","Motorcycles",R.drawable.wall_wallpaper_sections_11_motorcycles_motorcycles_01_jpg),
            Wall("City Glow","City",R.drawable.wall_wallpaper_sections_12_city_city_01_jpg)
        )
    }

    if (selected != null) {
        DetailScreen(
            wall=selected!!,
            isFavorite=favorites.contains(selected!!.res),
            onBack={selected=null},
            onFavorite={
                if (favorites.contains(selected!!.res)) favorites.remove(selected!!.res)
                else favorites.add(selected!!.res)
            },
            onPremium={
                if (selected!!.premium && !premium) {
                    premium=true
                    Toast.makeText(ctx,"Demo Premium unlocked",Toast.LENGTH_SHORT).show()
                } else {
                    applyWallpaper(ctx,selected!!.res)
                }
            }
        )
        return
    }

    Scaffold(
        containerColor=Bg,
        bottomBar={
            NavigationBar(containerColor=Surface) {
                val items=listOf(Icons.Default.Home,Icons.Default.Search,Icons.Default.Star,Icons.Default.Favorite,Icons.Default.Person)
                val labels=listOf("Home","Explore","Premium","Favorites","Profile")
                items.forEachIndexed { i,ic ->
                    NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(ic,null)},label={Text(labels[i])})
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when(tab) {
                0 -> HomeScreen(walls,category,{category=it},{selected=it})
                1 -> ExploreScreen(walls,category,{category=it},{selected=it})
                2 -> PremiumScreen(premium,{premium=true})
                3 -> FavoritesScreen(walls,favorites,{selected=it})
                else -> ProfileScreen()
            }
        }
    }
}

@Composable
fun Header(title:String,sub:String) {
    Column(Modifier.padding(horizontal=20.dp,vertical=18.dp)) {
        Text(title,fontSize=34.sp,fontWeight=FontWeight.Bold,color=Text)
        Text(sub,fontSize=15.sp,color=Muted)
    }
}

@Composable
fun CategoryRow(selected:String,onSelect:(String)->Unit) {
    val cats=listOf("All","Cars","4K","Nature","AMOLED","Gaming","Anime","Abstract","Minimal","Space","Neon","Motorcycles","City")
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
        cats.forEach { c ->
            FilterChip(selected=selected==c,onClick={onSelect(c)},label={Text(c)})
        }
    }
}

@Composable
fun HomeScreen(walls:List<Wall>,category:String,onCategory:(String)->Unit,onSelect:(Wall)->Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Header("EVO WALLS","Wallpapers for a better screen")
        CategoryRow(category,onCategory)
        Spacer(Modifier.height(14.dp))
        Text("TRENDING",fontWeight=FontWeight.Bold,color=Text,fontSize=20.sp,modifier=Modifier.padding(16.dp,8.dp))
        WallGrid(walls.filter{category=="All"||it.category==category},onSelect)
    }
}

@Composable
fun ExploreScreen(walls:List<Wall>,category:String,onCategory:(String)->Unit,onSelect:(Wall)->Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Header("Explore","Cars • 4K • Nature • AMOLED • Gaming and more")
        CategoryRow(category,onCategory)
        WallGrid(walls.filter{category=="All"||it.category==category},onSelect)
    }
}

@Composable
fun WallGrid(walls:List<Wall>,onSelect:(Wall)->Unit) {
    LazyVerticalGrid(columns=GridCells.Fixed(2),contentPadding=PaddingValues(12.dp),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        items(walls) { w ->
            Card(colors=CardDefaults.cardColors(containerColor=Surface),modifier=Modifier.clickable{onSelect(w)}) {
                Box {
                    Image(painter=androidx.compose.ui.res.painterResource(w.res),contentDescription=w.title,contentScale=ContentScale.Crop,modifier=Modifier.fillMaxWidth().height(260.dp))
                    if (w.premium) Text("PRO",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.align(Alignment.TopEnd).background(Red).padding(8.dp))
                }
                Column(Modifier.padding(10.dp)) {
                    Text(w.title,fontWeight=FontWeight.Bold,color=Text)
                    Text("4K • ${w.category}",fontSize=12.sp,color=Muted)
                }
            }
        }
    }
}

@Composable
fun DetailScreen(wall:Wall,isFavorite:Boolean,onBack:()->Unit,onFavorite:()->Unit,onPremium:()->Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Back",tint=Text)}
            Text(wall.title,fontSize=22.sp,fontWeight=FontWeight.Bold,color=Text,modifier=Modifier.weight(1f))
            IconButton(onClick=onFavorite){Icon(if(isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,"Favorite",tint=Red)}
        }
        Image(painter=androidx.compose.ui.res.painterResource(wall.res),contentDescription=wall.title,contentScale=ContentScale.Crop,modifier=Modifier.fillMaxWidth().weight(1f))
        Column(Modifier.padding(18.dp)) {
            Text("${wall.category} • 4K • Portrait",color=Muted)
            Spacer(Modifier.height(12.dp))
            Button(onClick=onPremium,modifier=Modifier.fillMaxWidth()) {
                Text(if(wall.premium) "Unlock / Apply Wallpaper" else "Set Wallpaper")
            }
        }
    }
}

@Composable
fun PremiumScreen(unlocked:Boolean,onUnlock:()->Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Spacer(Modifier.height(25.dp))
        Text("EVO Premium",fontSize=38.sp,fontWeight=FontWeight.Bold,color=Text)
        Text("Exclusive wallpapers. Extra features.",color=Muted)
        Spacer(Modifier.height(25.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF251216))) {
            Column(Modifier.padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                Text("♛",fontSize=64.sp,color=Red)
                Text("PREMIUM",fontSize=28.sp,fontWeight=FontWeight.Bold,color=Text)
                listOf("4K & Ultra HD","Exclusive drops","No ads","Unlimited downloads").forEach {
                    Text("✓  $it",color=Text,modifier=Modifier.padding(6.dp))
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        listOf("₹99 / month","₹699 / year","₹1,499 lifetime").forEach {
            Button(onClick=onUnlock,modifier=Modifier.fillMaxWidth().padding(vertical=5.dp)) { Text(it) }
        }
        if(unlocked) Text("Premium demo unlocked",color=Red,fontWeight=FontWeight.Bold,modifier=Modifier.padding(18.dp))
    }
}

@Composable
fun FavoritesScreen(walls:List<Wall>,favorites:List<Int>,onSelect:(Wall)->Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Header("Favorites","Your saved wallpapers")
        WallGrid(walls.filter{favorites.contains(it.res)},onSelect)
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
        Header("Profile","Manage your EVO WALLS experience")
        listOf("Downloads","Favorites","Notifications","Wallpaper quality","Appearance","Settings","About EVO WALLS").forEach {
            Card(colors=CardDefaults.cardColors(containerColor=Surface),modifier=Modifier.fillMaxWidth().padding(vertical=5.dp)) {
                Text(it,color=Text,fontSize=18.sp,modifier=Modifier.padding(20.dp))
            }
        }
    }
}

private fun applyWallpaper(context:Context,resId:Int) {
    try {
        val wm=WallpaperManager.getInstance(context)
        val bitmap=BitmapFactory.decodeResource(context.resources,resId)
        wm.setBitmap(bitmap)
        Toast.makeText(context,"Wallpaper applied",Toast.LENGTH_SHORT).show()
    } catch(e:Exception) {
        Toast.makeText(context,"Could not apply wallpaper",Toast.LENGTH_SHORT).show()
    }
}
